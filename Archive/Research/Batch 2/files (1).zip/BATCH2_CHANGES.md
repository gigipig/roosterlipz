# Batch 2 Changes Summary

## Files Modified
- `genetics.json` (v4.2-batch2)
- `genetics.js`

---

## 2A: G6PD Deficiency

**Gene:** G6PD (rs5030868 Mediterranean / rs1050828 African A-)
**Inheritance:** X-linked recessive

**Key frequencies:**
| Population | Frequency | Risk Level |
|------------|-----------|------------|
| Arabian | 40% | Elevated (up to 65% in some regions) |
| Central Africa | 22% | Elevated |
| Sahel | 20% | Elevated |
| Nile Valley | 20% | Elevated |
| Horn Somalia | 18% | Elevated |
| Caribbean Creole | 15% | Elevated |
| SE Asia | 10-12% | Moderate |
| Mediterranean | 6-8% | Moderate |
| Northern European | <1% | Low |
| East Asian | 1-4% | Low |
| Indigenous American | <1% | Low |

**Dietary impact:**
- Strictly avoid fava beans (favism)
- Avoid tonic water with quinine
- HbA1c unreliable for diabetes monitoring (artificially low)

---

## 2B: ABCA1 R230C (Indigenous American Exclusive)

**Gene:** ABCA1 (rs9282541)
**Inheritance:** Additive
**Population:** ONLY found in Indigenous American populations

**Key frequencies:**
| Population | Frequency |
|------------|-----------|
| Mesoamerica | 12% |
| Mestizo Mesoamerican | 10% |
| Andean | 10% |
| Amazon | 8% |
| Caribbean Taíno | 8% |
| Southwest US | 8% |
| Pacific NW | 7% |
| Patagonia | 7% |
| All non-American | 0% |

**Critical insight:** Carriers show **REVERSED diet response**
- Higher fat / lower carb diets produce BETTER metabolic outcomes
- Opposite of typical dietary advice
- 27% reduced cholesterol efflux, lower HDL-C

---

## 2C: SLC16A11 Diabetes Haplotype

**Gene:** SLC16A11 (rs75493593)
**Inheritance:** Additive
**Origin:** Neanderthal-introgressed

**Key frequencies:**
| Population | Frequency |
|------------|-----------|
| Mestizo Mesoamerican | 50% |
| Mesoamerica | 45% |
| Andean | 40% |
| Amazon | 35% |
| Caribbean Taíno | 30% |
| Southwest US | 28% |
| Great Plains | 25% |
| Patagonia | 25% |
| All European/African/Asian | 0-1% |

**Clinical impact:**
- OR 1.29 for type 2 diabetes
- Stronger effect in younger, leaner individuals
- Alters hepatic lipid metabolism
- Early intervention especially important

---

## 2D: TBC1D4 Diabetes (Inuit/Arctic)

**Gene:** TBC1D4 (p.Arg684Ter)
**Inheritance:** Recessive

**Key frequencies:**
| Population | Frequency |
|------------|-----------|
| Inuit | 17% |
| Subarctic | 8% |
| Siberia | 4% |
| Pacific NW | 2% |

**Clinical impact:**
- 10x T2D risk in homozygotes (4% of Greenlandic Inuit)
- Explains 10-15% of all diabetes in Greenland
- Severe muscle insulin resistance
- **BUT** exercise-stimulated glucose uptake preserved
- HbA1c misses 32% of cases — use oral glucose tolerance test

**Key recommendation:** Exercise is CRITICAL for carriers

---

## 2E: Expanded CREBRF and CPT1A Coverage

### CREBRF rs373863828 (Pacific Islander "Thrifty Gene")

**Key frequencies:**
| Population | Frequency |
|------------|-----------|
| Polynesia | 26% |
| Maori | 25% |
| Micronesia | 12% |
| Melanesia | 8% |
| SE Asia Island | 3% |
| Malagasy | 3% |

**PARADOX:** 
- Each copy increases BMI by 1.36-1.48 kg/m²
- BUT **PROTECTS** against type 2 diabetes (OR 0.59-0.65)
- Focus on preventing weight gain, not diabetes

### CPT1A rs80356779 P479L (Arctic Fat Metabolism)

**Key frequencies:**
| Population | Frequency |
|------------|-----------|
| Inuit | 76% (near fixation) |
| Subarctic | 50% |
| Siberia | 30% |
| Pacific NW | 15% |
| Canadian Prairies | 10% |
| Mongolia | 8% |

**Effect:**
- Adapted for high-fat marine diet
- Reduces DHA levels
- -2.1cm height per copy
- Traditional diet is metabolically optimal for carriers

---

## Files Changed in genetics.js

### GENE_META (line ~1065)
```javascript
g6pd_deficiency: { icon: '🫘', title: 'G6PD Deficiency', cssClass: 'g6pd' },
abca1_r230c: { icon: '🫀', title: 'Cholesterol Efflux (R230C)', cssClass: 'abca1' },
slc16a11_diabetes: { icon: '🩸', title: 'SLC16A11 Diabetes Risk', cssClass: 'slc16a11' },
tbc1d4_diabetes: { icon: '🏔️', title: 'Arctic Diabetes Risk (TBC1D4)', cssClass: 'tbc1d4' }
```

### GENERIC_GENE_CONFIG (line ~1248)
Full threshold configurations for all 4 new genes with appropriate risk levels and recommendations.

### POPULATION_SPECIFIC_GENES (line ~1296)
```javascript
g6pd_deficiency: { minFreq: 5, freqPath: 'allele_frequency_percent' },
abca1_r230c: { minFreq: 3, freqPath: 'allele_frequency_percent' },
slc16a11_diabetes: { minFreq: 5, freqPath: 'allele_frequency_percent' },
tbc1d4_diabetes: { minFreq: 3, freqPath: 'allele_frequency_percent' }
```

---

## Validation Samples

```
ARABIAN:
  G6PD: 40% (elevated) - fava bean avoidance critical

MESTIZO_MESOAMERICAN:
  ABCA1 R230C: 10% (reversed diet response)
  SLC16A11: 50% (high diabetes risk)

INUIT:
  TBC1D4: 17% (elevated) - exercise critical, use OGTT not HbA1c
  CPT1A: 76% (arctic adapted) - traditional diet optimal

POLYNESIA:
  CREBRF: 26% (thrifty gene) - BMI up but diabetes protection
```

---

## CSS Classes to Add (optional)

```css
.genetic-trait.g6pd { background: linear-gradient(135deg, #8B0000 0%, #CD5C5C 100%); color: #ffffff; }
.genetic-trait.abca1 { background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%); color: #ffffff; }
.genetic-trait.slc16a11 { background: linear-gradient(135deg, #4A0E4E 0%, #8E44AD 100%); color: #ffffff; }
.genetic-trait.tbc1d4 { background: linear-gradient(135deg, #1B4F72 0%, #5DADE2 100%); color: #ffffff; }
```
