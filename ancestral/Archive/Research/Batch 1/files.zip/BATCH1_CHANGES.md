# Batch 1 Changes Summary

## Files Modified
- `genetics.json` (v4.1-batch1)
- `genetics.js`

---

## 1A: African & Middle Eastern Lactase Persistence Alleles

**Problem:** The app only tested rs4988235 (European LP allele), misclassifying lactose-tolerant Africans and Middle Easterners as intolerant.

**Solution:** Added three new fields to every culture's `lactase_persistence` entry:
- `african_allele_gc14010` (rs145946881) - East African pastoralist variant
- `middle_eastern_allele_tg13915` (rs41380347) - Middle Eastern variant  
- `african_allele_cg13907` (rs41525747) - Horn of Africa variant

**Key frequencies added:**
| Population | G/C-14010 | T/G-13915 | C/G-13907 |
|------------|-----------|-----------|-----------|
| Maasai | 58% | 0% | 0% |
| Ethiopia | 45% | 20% | 15% |
| Nilotic | 39% | 0% | 0% |
| Arabian | 0% | 70% | 0% |
| Mesopotamian | 0% | 55% | 0% |
| Horn Somalia | 25% | 20% | 21% |

**Code change:** Modified `calculateLactasePersistence()` in genetics.js to check all LP alleles and use the **maximum frequency** among them.

---

## 1B: AMY1 Copy Number Updates (2024 Pangenome Study)

**Problem:** AMY1 copy numbers were too uniform across populations.

**Solution:** Updated copy numbers based on 2024 Nature pangenome findings:
- **Agricultural populations:** 6.7-7.5 copies (rice, wheat, maize farmers)
- **Pastoral populations:** 5.0-6.0 copies (cattle/sheep herders)
- **Hunter-gatherer/fishing:** 4.5-5.5 copies (lowest starch traditional diets)

**Key updates:**
| Population | Old | New | Reason |
|------------|-----|-----|--------|
| Inuit | 6 | 4.5 | Almost no traditional starch |
| Maasai | missing | 5.0 | Pastoral, blood/milk diet |
| Mongol | 6 | 5.0 | Nomadic pastoral |
| Mesoamerica | 7.5 | 7.5 | Long maize agriculture |
| Mesopotamian | 7 | 7.2 | Earliest agricultural center |

---

## 1C: Allele Frequency Corrections

### FADS1 rs174537 (Omega-3 Conversion)
| Population | Old | New | Impact |
|------------|-----|-----|--------|
| Central Africa | 95% | 95% | ✓ Correct |
| Ethiopia | 92% | 92% | ✓ Correct |
| Amazon | varied | 15% | Native American very low |
| Inuit | varied | 8% | Arctic adapted - lowest |
| Mesoamerica | varied | 18% | Native American low |

**Clinical impact:** Native Americans require preformed DHA/EPA from fish; plant ALA conversion is minimal.

### FTO rs9939609 (Obesity Risk)
- African populations: ~48% (highest globally)
- European populations: ~40-42% (lower than commonly cited)

### BCMO1 rs12934922 (Beta-Carotene → Vitamin A)
- African populations: ~4% (efficient converters)
- European populations: ~24% (reduced conversion, need preformed vitamin A)

### TCF7L2 rs7903146 (Diabetes Risk)
- East Asian: ~3% T allele (10x lower than Europeans)
- European: ~30% T allele

### HFE rs1800562 (Hemochromatosis)
- Western Europe (Celtic): increased to 10%
- Nordic: 8%

---

## Validation Samples

```
ETHIOPIA:
  LP: 45% European + 45% African G/C-14010 + 20% Middle Eastern + 15% C/G-13907
  AMY1: 7.0 (agricultural - teff)
  FADS1: 92% (African high)

AMAZON:
  LP: 1% (non-pastoral)
  AMY1: 5.0 (hunter-gatherer)
  FADS1: 15% (Native American low)

INUIT:
  LP: 2% (no dairy tradition)
  AMY1: 4.5 (lowest - no starch)
  FADS1: 8% (Arctic-adapted, fish diet)

ARABIAN:
  LP: 70% Middle Eastern allele
  AMY1: 5.8 (pastoral)
```

---

## Testing Notes

1. A user selecting 4 Maasai grandparents should now show **high LP** (from African G/C-14010) instead of low
2. A user selecting Inuit grandparents should show **very low FADS1** with recommendation for fish/algae omega-3
3. AMY1 phenotypes now correctly reflect agricultural vs pastoral vs hunter-gatherer ancestry
